Skin:
Former jTagEditor Skin

Install:
- Download the zip file
- Unzip it in your markItUp! skins folder
- Modify your CSS link to point at this skin