<?php
$sites = array(
	'empflix.com'      => 'empflix',
	'gaytube.com'      => 'gaytube',
	'pornhub.com'      => 'pornhub',
	'pornrabbit.com'   => 'pornrabbit',
	'redtube.com'      => 'redtube',	
	'tnaflix.com'      => 'tnaflix',
	'xvideos.com'      => 'xvideos',
	'youporn.com'      => 'youporn',
	'boafoda.com'      => 'boafoda'
);
?>
